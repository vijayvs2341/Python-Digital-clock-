from tkinter import *
from time import strftime
from PIL import Image, ImageTk
import random

root = Tk()
root.title("Digital Clock with Background")
root.geometry("600x350")
root.resizable(False, False)

# -----------------------------
# Load multiple background images
# -----------------------------
backgrounds = [
    "as.jpg",
    "asd.jpg",
    "ass.jpg",
    "sss.jpg"
]

# Randomly choose one image
bg_image = Image.open(random.choice(backgrounds))
bg_image = bg_image.resize((600, 350), Image.LANCZOS)
bg_photo = ImageTk.PhotoImage(bg_image)

# Display background
bg_label = Label(root, image=bg_photo)
bg_label.place(x=0, y=0, relwidth=1, relheight=1)

# -----------------------------
# Time display
# -----------------------------
def time():
    current_time = strftime("%H:%M:%S %p")
    label.config(text=current_time)
    label.after(1000, time)

# Date display
def update_date():
    date_label.config(text=strftime("%A, %d %B %Y"))
    date_label.after(60000, update_date)

# Clock label
label = Label(root, font=("ds-digital", 60, "bold"), bg="black", fg="cyan")
label.place(relx=0.5, rely=0.4, anchor='center')

# Date label
date_label = Label(root, font=("ds-digital", 20), bg="black", fg="white")
date_label.place(relx=0.5, rely=0.65, anchor='center')

time()
update_date()

root.mainloop()
